function [gc, gk, yend] = solve_only(inv_mutil, betav, kgrid, ymax)

% Returns the policy function evaluated at the ENDOGENOUS capital grid
% 
% Input:
%   inv_mutil: a function handle that computes the inverse of marginal utility
%   betav: beta*v, where v is a vector of value function evaluated on kgrid
%   kgrid: a vector of grid points for savings
%   ymax: the maximal cash-on-hands possible
% Output:
%   gc, gk : policy functions on the endogneous grid
%   yend : endogenous grid


Nk = length(kgrid);

betaDv = diff(betav)./diff(kgrid);
lambda = betaDv;

cstar = inv_mutil(lambda);

yL = kgrid(1);
yH = max([cstar(end)+kgrid(Nk), ymax])+0.1*abs(ymax);


% Endogenous grid
yend = zeros(2*Nk,1);
gc = zeros(2*Nk,1);

yend(1) = yL;
yend(2*Nk) = yH;

gc(1) = 0;
gc(2*Nk) = yH - kgrid(end);

for ik=1:Nk-1
    yend(2*ik) = cstar(ik)+kgrid(ik);
    yend(2*ik+1) = cstar(ik)+kgrid(ik+1);
    gc(2*ik) = cstar(ik);
    gc(2*ik+1) = cstar(ik);
end

gk = yend-gc;
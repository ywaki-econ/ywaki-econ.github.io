function [v, gc, inv_dist, R, ir, AggAvec] = solve_Huggett_model(ifm, Do_pfi, Use_mex, tolA, tolv, maxiter, NoDisp, print_skip)


    % copy parameters from ifm
    dt = ifm.dt;
    kgrid = ifm.kgrid;
    Nk = ifm.Nk;
    Ne = ifm.Ne;

    RL = 1+0.01*dt;
    RH = 1+0.04*dt;

    tolR = 1e-8;


    Nr = 100;

    AggAvec = zeros(Nr,1);

    init_cond = []; 

for ir=1:Nr


    % update a guess for R
    R = 0.5*(RL+RH);

    ifm.update_R(R);
    ifm.update_ygrid();

    % solve Income Fluctuation model
    [v, gc, Ptildemat, iter, v_update] = solve_IF_model(ifm,init_cond, Do_pfi, Use_mex, tolv, maxiter, NoDisp, print_skip);
    init_cond = dictionary(["gc", "v"],{gc, v});

    % compute an invariant distribution

    % Method 1: compute an eigenvector associated with the largest eigenvalue
    
    % [V,D,flag] = eigs(Ptildemat',1);
    % inv_dist = V/sum(V);
    
    % Method 2: Iterate for a fixed, finite number of times
    % if ir ==1
    %    inv_dist = ones(Nk*Ne,1)/(Nk*Ne);
    % end
    % 
    % for iter_p = 1:100
    %     inv_dist1 = Ptildemat'*inv_dist;
    %     inv_dist = inv_dist1;
    % end
     
    % Method 3:  Moll's "dirty trick" [taken from his huggett_equilibrium_iterate.m]
    
    AT = Ptildemat'-speye(Nk*Ne);
    b = zeros(Ne*Nk,1);
    
    i_fix = 1;
    b(i_fix)=.1;
    row = [zeros(1,i_fix-1),1,zeros(1,Ne*Nk-i_fix)];
    AT(i_fix,:) = row;
    
    inv_dist = AT\b;
    inv_dist = inv_dist./sum(inv_dist);
    
    % Aggregate savings
    AggA = inv_dist'*repmat(kgrid,Ne,1);
    
    
    % Bisection method update
    if (RH-RL)<tolR || abs(AggA)<tolA
        if ~NoDisp
            disp(['Outer loop converged instep = ', num2str(ir), '. R = ', num2str(R, '%.10f')])
            disp(['   Inner loop converged in Step = ', num2str(iter), ', updating distance (v) = ', num2str(v_update,10)])
            disp(['   Aggregate savings = ', num2str(AggA)])
        end
        break    
    elseif AggA>tolA
        RH = R; 
    elseif AggA<-tolA
        RL = R;
    end
    
    AggAvec(ir) = AggA;

    if ~NoDisp
        disp(['Outer loop step = ', num2str(ir), '. R = ', num2str(R,'%.10f')])
        disp(['   Inner loop converged in Step = ', num2str(iter), ', updating distance (v) = ', num2str(v_update,10)])
        disp(['   Aggregate savings = ', num2str(AggA)])
    end

end


end
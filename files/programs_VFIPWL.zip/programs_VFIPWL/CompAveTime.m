% Model initialization
%----------------------

% Model with grid size = 10000
rm = RamseyModel();
rm.sscalc();
rm.init_grid();

% Model with grid size = 1000
rm2 = RamseyModel();
rm2.sscalc();
rm2.init_grid(1000);

% Solve the model for Nrepeat times and computes the averate time
Nrepeat = 1000;

% Compute the average computing time 
disp('Grid size = 10000')

tic; 
for i=1:Nrepeat
[~, ~, iter_VFI, ~, c_update] = solve_model(rm,0,0,1e-6,1000,1);
end
totaltime = toc;
iter_VFI = double(iter_VFI);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_VFI;

disp('VFI')
disp(['Converged in step ', num2str(iter_VFI), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])


tic; 
for i=1:Nrepeat
[~,~, iter_EGM] = solve_model_EGM(rm,c_update,1000,1);
end
totaltime = toc;
iter_EGM = double(iter_EGM);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_EGM;

disp('EGM')
disp(['Converged in step ', num2str(iter_EGM), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])


tic; 
for i=1:Nrepeat
[~, ~, iter_PFI] = solve_model(rm,1,1,1e-6,1000,1);
end
totaltime = toc;
iter_PFI = double(iter_PFI);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_PFI;

disp('PFI')
disp(['Converged in step ', num2str(iter_PFI), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])

tic; 
for i=1:Nrepeat
[~, ~, iter_MPFI] = solve_model(rm,2,1,1e-6,1000,1);
end
totaltime = toc;
iter_MPFI = double(iter_MPFI);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_MPFI;

disp('MPFI')
disp(['Converged in step ', num2str(iter_MPFI), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])


disp(' ')
disp('Grid size = 1000')

tic; 
for i=1:Nrepeat
[~, ~, iter_VFI, ~, c_update] = solve_model(rm2,0,0,1e-6,1000,1);
end
totaltime = toc;
iter_VFI = double(iter_VFI);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_VFI;

disp('VFI')
disp(['Converged in step ', num2str(iter_VFI), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])


tic; 
for i=1:Nrepeat
[~,~, iter_EGM] = solve_model_EGM(rm2,c_update,1000,1);
end
totaltime = toc;
iter_EGM = double(iter_EGM);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_EGM;

disp('EGM')
disp(['Converged in step ', num2str(iter_EGM), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])


tic; 
for i=1:Nrepeat
[~, ~, iter_PFI] = solve_model(rm2,1,1,1e-6,1000,1);
end
totaltime = toc;
iter_PFI = double(iter_PFI);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_PFI;

disp('PFI')
disp(['Converged in step ', num2str(iter_PFI), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])

tic; 
for i=1:Nrepeat
[~, ~, iter_MPFI] = solve_model(rm2,2,1,1e-6,1000,1);
end
totaltime = toc;
iter_MPFI = double(iter_MPFI);
average_time = totaltime/Nrepeat;
perstep_time = average_time/iter_MPFI;

disp('MPFI')
disp(['Converged in step ', num2str(iter_MPFI), ', Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])

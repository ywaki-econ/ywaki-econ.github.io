# Description

This folder contains a set of sample code for Waki (2025), "A Fast and Convergent Hybrid of Value Function Iteration and the Endogenous Grid Method for Discrete-Time Income Fluctuation Problems."

# Files in the folder

## Ramsey model
* RamseyModel.m defines the class RamseyModel.
* solve_model solves the Ramsey model using the method proposed in the paper.
* solve_model solves the Ramsey model using the standard endogenous grid method.
* CompAveTime.m calculates the average computational time for all methods (VFI, PFI, and MPFI) for two grid sizes (I_k = 1,000 and 10,000). [Tables 1,2, and 3]
* CompareMethods.m compares the policy functions obtained from various methods, in terms of their differences and the Euler equation errors. [Table 5] 

## Huggett model
* IncomeFluctuationProblem.m defines the class IncomeFluctuationProblem.
* solve_IF_model.m solves an income fluctuation problem using the method proposed in the paper. 
* solve_Huggett_model.m solves for a stationary equilibrium in the Huggett model, where the real interest rate is updated using the bisection method. 
* CompAveTimeHuggett.m calculates the average computational time for all methods (VFI, PFI, and MPFI) for two grid sizes (I_k = 1,000 and 10,000). [Table 6]

## Methods
* solve_and_eval.m : Implement the algorithm 1 in the paper to evaluate the analytical policy function on an EXOGENOUS cash-on-hand grid. 
* solve_only.m : Implement the algorithm 1 in the paper to obtain the analytical policy function on an ENDOGENOUS cash-on-hand grid. 
* policy_endogenous_grid returns the endogenous cash-on-hand grid and the policy functions' values on it, by calling solve_only.m.
* euler_error computes the Euler equation error.
* modify_solution implements the modification of a solution using the endogenous grid method.
* find_subinterval.m : A subroutine that takes two increasing grids, xq and x, and for each element of xq[i], find j such that x[j] <= xq[i] <= x[j+1]. 
* concavify.m : Concavify the value function obtained by PFI
* solve_and_eval_EGM.m : Use the standard endogenous grid method to evaluate the analytical policy function on both EXOGENOUS and ENDOGENOUS cash-on-hand grids. 

## Continuous-time method
In the subfolder cont_time, 
* CompAveTime.m computes the numbers in Table 4, using HJB_NGM_implicit.m
* CompAveTimeHuggett.m computes the numbers in Table 6, using huggett_equilibrium_iterate.m

Both HJB_NGM_implicit.m and huggett_equilibrium_iterate.m need be downloaded from Ben Moll's webpage (URLs are in the paper), and one needs to comment out or remove all disp and figure/plot commands. 

To change the grid size, one needs to set the parameter "I" in these codes to either 1000 or 10000. 

# Mexifying the m-function
I have experimented which part of the code should be mexfied, and found that it is most effective to mexify the concavification step in PFI and MPFI. 

The concavification step is implemented by an m function, concavify.m. To generate a mex function from concavify.m, open this folder in Matlab and execute the following command in the Command Window:

    codegen concavify

To use the generated mex function, set Use_mex = 1. If the mex function cannot be generated, set Use_mex = 0 and the programs use the m-function instead. 

Note that this option matters only for PFI and MPFI, and it does not make a difference for VFI. 


# Continuous-time limit of the Huggett Model
For the Huggett model, there is a parameter dt that can be set in HuggettGE.m. It represents the length of a time interval, and the default value is 1 (discrete-time). By lowering this value, one can approximate its continuous-time limit. In particular, when dt is set to 0.01, the conditional densities for asset becomes (visually) indistinguishable to the output of Ben Moll's code. (Note that the value of dt cannot be made lower.) 


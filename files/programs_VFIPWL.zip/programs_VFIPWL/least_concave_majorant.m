function k = least_concave_majorant(x,y) %#codegen

arguments
    x (:,1) double
    y (:,1) double
end

% x = (x1,x2,...,xn) in R^n, with n>1 and x1<x2<...<xn (SORTED)
% y = (y1,y2,...,yn) in R^n

% Returns a set of nodal points (index) of the least concave majorant of
% 2-dimensional data (x,y) using Andrew's monotone chain algorithm: 
% A. M. Andrew, 1979. "Another Efficient Algorithm for Convex Hulls in Two
% Dimensions", Info. Proc. Letters 9.
% https://doi.org/10.1016/0020-0190(79)90072-3

n = length(x);

if n ~= length(y)
    error('Lengths of x and y are different.')
end



if n==1
    k = 1;
elseif n==2
    k = [1;2];
else

    
cross_prod = @(o,a,b) (a(1) - o(1)) * (b(2) - o(2)) - (a(2) - o(2)) * (b(1) - o(1));

% Upper convex hull construction

candidates = zeros(n,2); % n*2 matrix to store candidate points
k = zeros(n,1); % n-dim vector to store candidate points' indices
j = 0; % total number of candidate points

for i = 1:n
    new_point = [x(i), y(i)]; % i-th data point

    if j < 2 
        % Add the new point to the candidate list as there is no enough
        % candidate points
        candidates(j+1,:) = new_point;
        k(j+1) = i;
        j = j+1;

    else

        while (j >= 2)& (cross_prod(candidates(j-1,:), candidates(j,:), new_point) >= 0)
            % Keep removing the last candidate point if it requires a
            % clockwise-rotation of vertex toward the new point
                candidates(j,:) = 0; % last candidate point is removed
                k(j) = 0;   % its index is removed
                j = j-1;    % total number of candidate points is reduced by one
            
            % Exit the while loop if only one candidate point remains after the removal 
            if j < 2
                break
            end
        end

        % After removing all invalid candidates, add the new point to the
        % list
        candidates(j+1,:) = new_point;
        k(j+1) = i;
        j = j+1;
    end
end

k = k(k>0); % remove unfilled elements of k

end
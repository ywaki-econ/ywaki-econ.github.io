function [v0, gc1vec, Ptildemat, iter, v_update, c_update] = solve_IF_model(ifm, init_cond, Do_pfi, Use_mex, tolv, maxiter, NoDisp, print_skip)

    arguments
        ifm IncomeFluctuationModel;
        init_cond;
        Do_pfi int16 = 0;
        Use_mex logical = 0;
        tolv double = 1e-6;
        maxiter int16 = 1000;
        NoDisp logical = 0;
        print_skip int16 = 10;
    end

    % copy parameters from ifm
    kgrid = ifm.kgrid;
    ygrid = ifm.ygrid;
    beta = ifm.beta;
    Nk = ifm.Nk;
    inv_mutil = @(c) ifm.inv_mutil(c);
    util = @(c) ifm.util(c);

    Ne = ifm.Ne;
    Tr_e_mat = ifm.Tr_e_mat;

    % define variables that are used repeatedly
    kgrid_stacked = repmat(kgrid,Ne,1);

    % initialization
    if isempty(init_cond)
        gc_val0 = ygrid(:)-kgrid_stacked;
        v0 = util(gc_val0)/(1-beta);
    else
        gc_val0 = init_cond{"gc"};
        v0 = init_cond{"v"};
    end


    % specify a function to concavify (relevant for PFI and MPFI only)
    if Use_mex == 1
        concavify_func = @(k,v) concavify_mex(k,v);
    else
        concavify_func = @(k,v) concavify(k,v);
    end


    v1 = zeros(Nk,Ne);
    v1c = zeros(Nk,Ne);
    gc_val = zeros(Nk,Ne);
    nnz = zeros(Ne,1);
        
    % solving the model:    
    if Do_pfi == 0 % VFI

        betav_cont = zeros(Nk,Ne);

        for iter = 1:maxiter
            
            v = reshape(v0,Nk,Ne);
        
            for ie=1:Ne
                [gc_val(:,ie), betav_cont(:,ie)] = solve_and_eval(inv_mutil, beta*v*Tr_e_mat(ie,:)', kgrid, ygrid(:,ie));
                v1(:,ie) = util(gc_val(:,ie))+betav_cont(:,ie);
            end
            
            v1vec = v1(:);
            v_update = max(abs(v1vec-v0));
            v0 = v1vec;
        
            gc1vec = gc_val(:);            
            c_update = max(abs(gc1vec-gc_val0));
            gc_val0 = gc1vec;
        
        
            if ~NoDisp && mod(iter,print_skip) == 0
                disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
            end
        
            if v_update < tolv
                if ~NoDisp
                    disp(['VFI converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
                end
                break;
            end    
        
        end

        Pi_cell = cell(Ne,1);
        Pj_cell = cell(Ne,1);
        Pval_cell = cell(Ne,1);
        for ie=1:Ne
            [gc_val(:,ie), ~, Pi_cell{ie}, Pj_cell{ie}, Pval_cell{ie}] = solve_and_eval(inv_mutil, beta*v*Tr_e_mat(ie,:)', kgrid, ygrid(:,ie));
            nnz(ie) = length(Pi_cell{ie});
        end
        nnz_all = sum(nnz);
        
        %% Construction of Ptilde. The following direct method works better for high Ne.
        Ptilde_i = zeros(nnz_all*Ne,1);
        Ptilde_j = zeros(nnz_all*Ne,1);
        Ptilde_val = zeros(nnz_all*Ne,1);
    
        loc = 0;
        for ie=1:Ne
            nnz_now = nnz(ie);
            for je=1:Ne
                Ptilde_i(loc+1:loc+nnz_now) = Nk*(ie-1)+Pi_cell{ie};
                Ptilde_j(loc+1:loc+nnz_now) = Nk*(je-1)+Pj_cell{ie};
                Ptilde_val(loc+1:loc+nnz_now) = Tr_e_mat(ie,je)*Pval_cell{ie};
                loc = loc + nnz_now;
            end
        end
    
        Ptildemat = sparse(Ptilde_i(1:loc),Ptilde_j(1:loc),Ptilde_val(1:loc),Ne*Nk, Ne*Nk);

        
    elseif Do_pfi == 1 % PFI

        Idmat = speye(Nk*Ne);
        Pi_cell = cell(Ne,1);
        Pj_cell = cell(Ne,1);
        Pval_cell = cell(Ne,1);
        

        for iter = 1:maxiter
            
            v = reshape(v0,Nk,Ne);
        
            for ie=1:Ne
                [gc_val(:,ie), ~, Pi_cell{ie}, Pj_cell{ie}, Pval_cell{ie}] = solve_and_eval(inv_mutil, beta*v*Tr_e_mat(ie,:)', kgrid, ygrid(:,ie));
                nnz(ie) = length(Pi_cell{ie});
            end
        
            nnz_all = sum(nnz);
        
            %% Construction of Ptilde. The following direct method works better for high Ne.
            Ptilde_i = zeros(nnz_all*Ne,1);
            Ptilde_j = zeros(nnz_all*Ne,1);
            Ptilde_val = zeros(nnz_all*Ne,1);
        
            loc = 0;
            for ie=1:Ne
                nnz_now = nnz(ie);
                for je=1:Ne
                    Ptilde_i(loc+1:loc+nnz_now) = Nk*(ie-1)+Pi_cell{ie};
                    Ptilde_j(loc+1:loc+nnz_now) = Nk*(je-1)+Pj_cell{ie};
                    Ptilde_val(loc+1:loc+nnz_now) = Tr_e_mat(ie,je)*Pval_cell{ie};
                    loc = loc + nnz_now;
                end
            end
        
            Ptildemat = sparse(Ptilde_i(1:loc),Ptilde_j(1:loc),Ptilde_val(1:loc),Ne*Nk, Ne*Nk);
        
        
            %% When Ne is low, the following is as good as the above construction.
            % Ptildemat = spalloc(Nk*Ne,Nk*Ne, nnz_all);
            % for ie=1:Ne
            %     Ptildemat(Nk*(ie-1)+1:Nk*ie,:) = kron(Tr_e_mat(ie,:), sparse(Pi_cell{ie} ,Pj_cell{ie}, Pval_cell{ie}, Nk,Nk));
            % end
        
            % Howard policy iteration
            B = (Idmat-beta*Ptildemat);
            b = util(gc_val(:));
            v1p = B\b;
            v1p = reshape(v1p,Nk,Ne);
            
            % concavify the resulting function        
            for ie=1:Ne
                v1c(:,ie) = concavify_func(kgrid, v1p(:,ie));
            end
        
            v1vec = v1c(:);
            v_update = max(abs(v1vec-v0));
            v0 = v1vec;
        
            gc1vec = gc_val(:);            
            c_update = max(abs(gc1vec-gc_val0));
            gc_val0 = gc1vec;

            if ~NoDisp && mod(iter,print_skip) == 0
                disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
            end
        
            if v_update < tolv
                if ~NoDisp
                    disp(['VFI converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
                end
                break;
            end    
        end
        
    elseif Do_pfi == 2 %MPFI

        Pi_cell = cell(Ne);
        Pj_cell = cell(Ne);
        Pval_cell = cell(Ne);
        

        for iter = 1:maxiter
            
            v = reshape(v0,Nk,Ne);
        
            for ie=1:Ne
                [gc_val(:,ie), ~, Pi_cell{ie}, Pj_cell{ie}, Pval_cell{ie}] = solve_and_eval(inv_mutil, beta*v*Tr_e_mat(ie,:)', kgrid, ygrid(:,ie));
                nnz(ie) = length(Pi_cell{ie});
            end
        
            nnz_all = sum(nnz);
        
            %% Construction of Ptilde. The following direct method works better for high Ne.
            Ptilde_i = zeros(nnz_all*Ne,1);
            Ptilde_j = zeros(nnz_all*Ne,1);
            Ptilde_val = zeros(nnz_all*Ne,1);
        
            loc = 0;
            for ie=1:Ne
                nnz_now = nnz(ie);
                for je=1:Ne
                    Ptilde_i(loc+1:loc+nnz_now) = Nk*(ie-1)+Pi_cell{ie};
                    Ptilde_j(loc+1:loc+nnz_now) = Nk*(je-1)+Pj_cell{ie};
                    Ptilde_val(loc+1:loc+nnz_now) = Tr_e_mat(ie,je)*Pval_cell{ie};
                    loc = loc + nnz_now;
                end
            end
        
            Ptildemat = sparse(Ptilde_i(1:loc),Ptilde_j(1:loc),Ptilde_val(1:loc),Ne*Nk, Ne*Nk);
        
        
            %% When Ne is low, the following is as good as the above construction.
            % Ptildemat = spalloc(Nk*Ne,Nk*Ne, nnz_all);
            % for ie=1:Ne
            %     Ptildemat(Nk*(ie-1)+1:Nk*ie,:) = kron(Tr_e_mat(ie,:), sparse(Pi_cell{ie} ,Pj_cell{ie}, Pval_cell{ie}, Nk,Nk));
            % end
        
            % Modified PFI
            v0p = v0;
            b = util(gc_val(:));
            bet_P = beta*Ptildemat;
            for iter_p=1:20
                v1p =  b + bet_P*v0p;
                v0p = v1p;
            end
            v1p = reshape(v1p,Nk,Ne);

            % concavify the resulting function        
            for ie=1:Ne
                v1c(:,ie) = concavify_func(kgrid, v1p(:,ie));
            end
        
            v1vec = v1c(:);
            v_update = max(abs(v1vec-v0));
            v0 = v1vec;
        
            gc1vec = gc_val(:);            
            c_update = max(abs(gc1vec-gc_val0));
            gc_val0 = gc1vec;
        
            if ~NoDisp && mod(iter,print_skip) == 0
                disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
            end
        
            if v_update < tolv
                if ~NoDisp
                    disp(['VFI converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
                end
                break;
            end    
        
        
        end
    end


    

end


function loc = find_subinterval(xq,x)

%#codegen
arguments
    xq (:,:) double
    x (:,:) double
end 


% For
%  xq : Nxq*1 matrix
%  x : Nx*1 matrix
% the function finds loc so that for each (i, m)
%  x[loc,m] <= xq[i, m] < x[loc+1,m]
%
% Requirements: 
%   1. For each m, xq(:,m) and x(:,m) are in an ascending order.
%   2. For each (i,m), x(1,m) <= xq(i,m) < x(end,m).

Nxq = length(xq);
Nx = length(x);

loc = zeros(Nxq, 1);

xloc_now = 1;
for iq = 1:Nxq
    xq_now = xq(iq,1);
    for xloc = xloc_now:(Nx-1)
        if x(xloc+1,1) >= xq_now
            loc(iq, 1) = xloc;
            xloc_now = xloc;
            break;
        end
    end
end

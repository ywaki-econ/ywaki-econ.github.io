function EEerror = euler_error(rm, gc, yend, gc_exo, gk_exo)

    arguments
        rm RamseyModel;
        gc (:,:) double;
        yend (:,:) double;
        gc_exo (:,:) double;
        gk_exo (:,:) double;
    end

cnext_val = interp1(yend, gc, rm.ProdFunc(gk_exo) );
EEerror = rm.inv_mutil( rm.beta*rm.mutil( cnext_val ).*rm.MProdFunc(gk_exo) )./gc_exo-1;

end
function [gc_exo, pol_end, iter, c_update] = solve_model_EGM(rm, tolc, maxiter, NoDisp, print_skip)

    arguments
        rm RamseyModel;
        tolc double = 1e-8;
        maxiter int16 = 1000;
        NoDisp logical = 0;
        print_skip int16 = 10;
    end

    % copy parameters from rm
    kgrid = rm.kgrid;
    ygrid = rm.ygrid;
    beta = rm.beta;
    inv_mutil = @(mu) rm.inv_mutil(mu);

    % initialization
    gc_exo = ygrid-kgrid;
    v0 = rm.util(gc_exo)/(1-beta);
    Dv0 = rm.mutil(gc_exo).*(rm.MProdFunc(kgrid)-1)/(1-beta);

    
    for iter = 1:maxiter
        
        gc_exo0 = gc_exo;
    
    %    gc_all(:,iter) = gc_exo0;
    %    v_all(:,iter) = v0;
        
        Dv = Dv0;
    
        [gc_exo, ~, pol_end] = solve_and_eval_EGM(inv_mutil, beta*Dv, kgrid, ygrid);
    
        Dv1 = rm.mutil(gc_exo).*rm.MProdFunc(kgrid);
        Dv0 = Dv1;
    
        c_update = max(abs(gc_exo-gc_exo0));
    
        if ~NoDisp && mod(iter,print_skip) == 0
            disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5)])
        end
    
        %--- Uncomment the following part to figure out 
    
        % v1 = util(gc_exo) + beta*interp1(kgrid, v0, gk_exo);
        % v_update = max(abs(v1-v0));
        % v0 = v1;
        % disp(['V updating distance = ', num2str(v_update,10)])
    
        % if v_update < tolv
        %     break;
        % end
        
        
        if c_update < tolc
            if ~NoDisp
                disp(['EGM converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5)])
            end
            break;
        end    
    
    
    end

end
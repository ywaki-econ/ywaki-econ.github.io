function f_out = concavify(x, f)

%#codegen
arguments
    x (:,1) double
    f (:,1) double
end 

minf = min(f);
nx = length(x);
ind = convhull([ [x; x(nx); x(1)], [f;minf-10; minf-10] ]);

f_out = f;

if length(ind)<=nx+1
    ind = sort(ind);

    for l = 1:length(ind)-1
        l0 = ind(l);
        l1 = ind(l+1);
        if l1-1>l0
           f_out(l0+1:l1-1,1) = f(l0) + (f(l1)-f(l0))/(x(l1)-x(l0))*(x(l0+1:l1-1)-x(l0));
        end        
    end
end
function f_out = concavify(x, f)

%#codegen
arguments
    x (:,1) double
    f (:,1) double
end 

nx = length(x);

ind = least_concave_majorant(x,f); % vector of indices of nodal points

f_out = f;

ni = length(ind);

% piecewise-linear interpolation of nodal points evaluated on non-nodal points
if ni<=nx+1

    for l = 1:ni-1
        l0 = ind(l);
        l1 = ind(l+1);
        if l1-1>l0
           f_out(l0+1:l1-1,1) = f(l0) + (f(l1)-f(l0))/(x(l1)-x(l0))*(x(l0+1:l1-1)-x(l0));
        end        
    end
end
classdef RamseyModel <handle
    properties
        beta = 1/(1+0.05);
        alpha = 0.3;
        delta = 0.05;
        sigma = 2;

        kss;
        yss;

        A;
        Nk;
        kgrid;
        ygrid; 
    end

    methods

        function self = sscalc(self,A)
            arguments
                self;
                A double = (1/self.beta-1+self.delta)/self.alpha;
            end
        
            self.A = A;
            self.kss = ((1/self.beta - 1+self.delta)/(self.alpha*self.A))^(1/(self.alpha-1));
            self.yss = self.ProdFunc(self.kss);
        end

        function self = init_grid(self,Nk,kmin,kmax,LogGrid)
            arguments
                self;
                Nk int16 = 10000;
                kmin double = 0.0001*self.kss;
                kmax double = 2*self.kss;
                LogGrid logical = 0;
            end

            self.Nk = Nk;

            if LogGrid
                self.kgrid = logspace(log10(kmin),log10(kmax),Nk)'; % log-spaced grid
            else
                self.kgrid = linspace(kmin, kmax, Nk)';   % equally-spaced grid
            end

            self.ygrid = self.ProdFunc(self.kgrid);
        end

        function y = ProdFunc(self, k) 
            y = self.A*k.^self.alpha+(1-self.delta)*k;
        end
    
        function mpk = MProdFunc(self,k)
            mpk = self.alpha*self.A*k.^(self.alpha-1)+(1-self.delta);
        end

        function u = util(self,c)
            if self.sigma == 1
                u = log(c);
            else
                u = real(c.^(1-self.sigma)/(1-self.sigma));
            end
        end

        function mu = mutil(self,c)
            mu = real(c.^(-self.sigma));
        end

        function c = inv_mutil(self,mu) 
            c = real(mu.^(-1/self.sigma));
        end

    end

end




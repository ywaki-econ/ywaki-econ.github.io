function [gc, gk, yend] = policy_endogenous_grid(rm, v0)

    arguments
        rm RamseyModel;
        v0 (:,:) double;
    end

    % copy parameters from rm
    kgrid = rm.kgrid;
    beta = rm.beta;
    inv_mutil = @(c) rm.inv_mutil(c);
    ymax = rm.ygrid(end);

    [gc, gk, yend] = solve_only(inv_mutil, beta*v0, kgrid, ymax);

end


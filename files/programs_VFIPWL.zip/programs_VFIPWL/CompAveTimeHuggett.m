% Model initialization
%----------------------

clear all

% Model with grid size = 10000
ifm = IncomeFluctuationModel();
ifm.init_timeinterval();
ifm.init_param();
ifm.init_shocks();
ifm.init_grid();

% Solve the model for Nrepeat times and computes the averate time
Nrepeat = 1000;


Use_mex = 1;
tolv = 1e-6;
maxiter = 1000;
NoDisp = 1;
print_skip = 20;

Method = {'PFI', 'MPFI'};
tolA = 1e-5;

% Compute the average computing time 
disp('Grid size = 10000')

for Do_pfi = 1:2

    tic; 
    for i=1:Nrepeat
        [v, gc, inv_dist, R, ir, AggAvec] = solve_Huggett_model(ifm, Do_pfi, Use_mex, tolA, tolv, maxiter, NoDisp, print_skip);
    end
    totaltime = toc;
    average_time = totaltime/Nrepeat;
    perstep_time = average_time/ir;
    
    disp(' ')
    disp(Method{Do_pfi})
    disp(['   Outer loop converged in step ', num2str(ir)])
    disp(['   Gross real interest = ', num2str(R,'%.10f')])
    disp(['   Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])
    
    % reset R and ygrid
    ifm.init_param();
    ifm.update_ygrid();

end


disp('Grid size = 1000')
ifm.init_param();
ifm.init_grid(1000);

for Do_pfi = 1:2

    tic; 
    for i=1:Nrepeat
        [v, gc, inv_dist, R, ir, AggAvec] = solve_Huggett_model(ifm, Do_pfi, Use_mex, tolA, tolv, maxiter, NoDisp, print_skip);
    end
    totaltime = toc;
    average_time = totaltime/Nrepeat;
    perstep_time = average_time/ir;
    
    disp(' ')
    disp(Method{Do_pfi})
    disp(['   Outer loop converged in step ', num2str(ir)])
    disp(['   Gross real interest = ', num2str(R,'%.10f')])
    disp(['   Ave. Time = ', num2str(average_time,'%e'), ', Per-step Time = ', num2str(perstep_time,'%e')])
    
    % reset R and ygrid
    ifm.init_param();
    ifm.update_ygrid();

end

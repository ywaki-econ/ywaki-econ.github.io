clear;
clc;

% Common misc. parameters

TotalIter = 1000;

% Misc. parameters
tic
for m=1:TotalIter
    huggett_equilibrium_iterate;
end

TotalTime =toc;

disp(['Continuous-time results, Nk = ', num2str(I)])
AveTime = TotalTime/TotalIter;
disp(['   Average time = ', num2str(AveTime),  ' , Outer loop steps = ', num2str(ir)])


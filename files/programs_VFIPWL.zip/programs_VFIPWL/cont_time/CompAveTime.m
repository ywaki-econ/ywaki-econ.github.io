clear;
clc; 

TotalIter = 1000;

tic
for m=1:TotalIter
    HJB_NGM_implicit;
end

TotalTime =toc;

disp('Average total time')
AveTime = TotalTime/TotalIter

disp('Number of iteration')
n

disp('Average per-iteration time')
AveTimeperIter = AveTime/n 

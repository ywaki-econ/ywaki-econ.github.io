function [gc_val, betav_cont, Pi, Pj, Pval] = solve_and_eval(inv_mutil, betav, kgrid, ygrid)

% Returns the policy function evaluated at the EXOGENOUS capital grid
%
% Input:
%   inv_mutil: a function handle that computes the inverse of marginal utility
%   betav: beta*v, where v is a vector of value function evaluated on kgrid
%   kgrid: a vector of grid points for savings
%   ygrid: a vector of grid points for cash-on-hands
% Output:
%   gc_val : consumption policy functions on kgrid
%   betav_cont : continuation utility (= discounted value from next period onward) on kgrid
%   (Pi, Pj, Pval) : Probability transition matrix representation of gk_val

Nk = length(kgrid);

betaDv = diff(betav)./diff(kgrid);
lambda = betaDv;

cstar = inv_mutil(lambda);

ymax = ygrid(end);

yL = kgrid(1);
yH = max([cstar(end)+kgrid(Nk), ymax])+0.1*abs(ymax);

% Endogenous grid
yend = zeros(2*Nk,1);
yend(1) = yL;
yend(2*Nk) = yH;


for ik=1:Nk-1
    yend(2*ik) = cstar(ik)+kgrid(ik);
    yend(2*ik+1) = cstar(ik)+kgrid(ik+1);
end

Ny = length(ygrid);
Nyend = length(yend);

yqind = (1:1:Ny)';
yind = (1:1:Nyend)';

gc_val = zeros(Ny,1);
gk_val = zeros(Ny,1);

betav_cont = zeros(Ny,1);

loc = find_subinterval(ygrid,yend);



% I intervals

isI = mod(loc,2)==0;

iloc_I = yqind(isI);
jloc_I = yind(loc(isI));

jk_I = (jloc_I)/2;
jk_Iplus1 = jk_I+1;

gc_val(iloc_I) = cstar(jk_I);
kp = ygrid(iloc_I) - gc_val(iloc_I);
gk_val(iloc_I) = kp;

wk_I = (kgrid(jk_Iplus1)-kp)./(kgrid(jk_Iplus1)-kgrid(jk_I));

betav_cont(iloc_I) = wk_I.*betav(jk_I) + (1-wk_I).*betav(jk_Iplus1);

% J intervals
isJ = ~isI;
iloc_J = yqind(isJ);
jloc_J = yind(loc(isJ));

jk_J = (jloc_J+1)/2;

gk_val(iloc_J) = kgrid(jk_J);
gc_val(iloc_J) = ygrid(iloc_J) - gk_val(iloc_J);

betav_cont(iloc_J) = betav(jk_J);

wk_J = ones(length(iloc_J),1);
ik_J = (jloc_J+1)/2;


if nargout>2    % Used only for PFI&MPFI.
    % Collect non-zero elements of P
    Pi = [iloc_I; iloc_I; iloc_J];
    Pj = [jk_I; jk_Iplus1; ik_J];
    Pval = [wk_I; 1-wk_I; wk_J];
end


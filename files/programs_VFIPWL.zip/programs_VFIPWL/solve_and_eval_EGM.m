function [gc_exo, gk_exo, pol_end] = solve_and_eval_EGM(inv_mutil, betaDv, kgrid, ygrid)


% inv_mutil: a function handle that computes the inverse of marginal utility
% betav: beta*v, where v is a vector of value function evaluated on kgrid
% kgrid: a vector of grid points for savings
% ygrid: a vector of grid points for cash-on-hands


lambda = betaDv;

cstar = inv_mutil(lambda);

ymax = ygrid(end);

% Endogenous grid
yend = cstar + kgrid;
gc_end = cstar;
gk_end = kgrid;

if ymax > yend(end)
    gc_end = [gc_end;
              (gc_end(end)-gc_end(end-1))/(yend(end)-yend(end-1))*(ymax-yend(end))];
    gk_end = [gk_end;
              (gk_end(end)-gk_end(end-1))/(yend(end)-yend(end-1))*(ymax-yend(end))];              
    yend = [yend;
            ymax];

end

gc_exo = interp1(yend,gc_end, ygrid);
gk_exo = ygrid - gc_exo;

pol_end = dictionary(["gc_end","gk_end","yend"],{gc_end, gk_end, yend});
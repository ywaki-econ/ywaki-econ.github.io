classdef IncomeFluctuationModel <handle
    properties

        dt;
        beta;
        sigma;

        R;

        Ne;
        evec;
        Tr_e_mat;
        inv_dist_e;

        Nk;
        kgrid;
        ygrid; 
    end

    methods

        function self = init_timeinterval(self,dt)
            arguments
                self;
                dt double = 1.0;
            end

            self.dt = dt;
        end

        function self = init_param(self,beta,sigma,R)
            arguments
                self;
                beta double = exp(-0.05*self.dt);
                sigma double = 2.0;
                R double = 1 + 0.01*self.dt;
            end

            self.beta = beta;
            self.sigma = sigma;
            self.R = R;

        end

        function self = init_grid(self,Nk,kmin,kmax,LogGrid)
            arguments
                self;
                Nk = 10000;
                kmin double = -0.15;
                kmax double = 5;
                LogGrid logical = 0;
            end

            self.Nk = Nk;

            if LogGrid
                self.kgrid = logspace(log10(kmin),log10(kmax),Nk)'; % log-spaced grid
            else
                self.kgrid = linspace(kmin, kmax, Nk)';   % equally-spaced grid
            end

            self.ygrid = zeros(Nk, self.Ne);
            for ie=1:self.Ne
                self.ygrid(:,ie) = self.ProdFunc(self.kgrid,self.evec(ie));
            end

        end

        function self = init_shocks(self, Ne, evec, Tr_e_mat)
            arguments
                self;
                Ne = 2;
                evec (:,1) double = [0.2; 0.1]*self.dt;
                Tr_e_mat (:,:) = [0.8, 0.2;
                                  0.2, 0.8];
            end
            self.Ne = Ne;
            self.evec = evec;
            self.Tr_e_mat = Tr_e_mat;
            V = eigs(self.Tr_e_mat',1);
            self.inv_dist_e = V/sum(V);
        end

        function self = update_R(self, R)
            self.R = R;
        end

        function self = update_ygrid(self)
            for ie=1:self.Ne
                self.ygrid(:,ie) = self.ProdFunc(self.kgrid,self.evec(ie));
            end
        end


        function y = ProdFunc(self, k,e) 
            y = self.R*k+e;
        end

        function u = util(self,c)
            if self.sigma == 1
                u = log(c);
            else
                u = real(c.^(1-self.sigma)/(1-self.sigma));
            end
        end

        function mu = mutil(self,c)
            mu = real(c.^(-self.sigma));
        end

        function c = inv_mutil(self,mu) 
            c = real(mu.^(-1/self.sigma));
        end

    end

end




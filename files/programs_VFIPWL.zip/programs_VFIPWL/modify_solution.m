function [gc_exo_modified, pol_end] = modify_solution(rm, gc_exo, nstep)

    arguments
        rm RamseyModel;
        gc_exo (:,:) double;
        nstep int16;
    end

    % copy parameters from rm
    kgrid = rm.kgrid;
    ygrid = rm.ygrid;
    beta = rm.beta;
    inv_mutil = @(c) rm.inv_mutil(c);
    mutil = @(c) rm.mutil(c);
    MProdFunc = @(k) rm.MProdFunc(k);
    
    gc_0 = gc_exo;
    for i = 1:nstep
        Dv0 = mutil(gc_0).*MProdFunc(kgrid);
 
        [gc_1, ~, pol_end] = solve_and_eval_EGM(inv_mutil, beta*Dv0, kgrid, ygrid);

        gc_0 = gc_1;

    end

    gc_exo_modified = gc_1;

end
function [v0, gc_val, iter, v_update, c_update] = solve_model(rm, Do_pfi, Use_mex, tolv, maxiter, NoDisp, print_skip)

    arguments
        rm RamseyModel;
        Do_pfi int16 = 0;
        Use_mex logical = 0;
        tolv double = 1e-6;
        maxiter int16 = 1000;
        NoDisp logical = 0;
        print_skip int16 = 10;
    end

    % copy parameters from rm
    kgrid = rm.kgrid;
    ygrid = rm.ygrid;
    beta = rm.beta;
    Nk = rm.Nk;
    inv_mutil = @(c) rm.inv_mutil(c);
    ProdFunc = @(k) rm.ProdFunc(k);
    util = @(c) rm.util(c);

    % initialization
    gc_val0 = ProdFunc(kgrid)-kgrid;
    v0 = util(gc_val0)/(1-beta);

    % specify a function to concavify (relevant for PFI and MPFI only)
    if Use_mex == 1
        concavify_func = @(k,v) concavify_mex(k,v);
    else
        concavify_func = @(k,v) concavify(k,v);
    end

    % solving the model:    
    if Do_pfi == 0 % VFI

        for iter = 1:maxiter
            
            v = v0;
        
            [gc_val, betav_cont] = solve_and_eval(inv_mutil, beta*v, kgrid, ygrid);
    
            v1 = util(gc_val)+betav_cont;
         
            v_update = max(abs(v1-v0));
        
            c_update = max(abs(gc_val-gc_val0));
            gc_val0 = gc_val;
        
            v0 = v1;
        
            if ~NoDisp && mod(iter,print_skip) == 0
                disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
            end
        
            if v_update < tolv
                if ~NoDisp
                    disp(['VFI converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
                end
                break;
            end    
        
        end

    elseif Do_pfi == 1 % PFI

        Idmat = speye(Nk);

        for iter = 1:maxiter
            
            v = v0;
        
            [gc_val, ~, Pi, Pj, Pval] = solve_and_eval(inv_mutil, beta*v, kgrid, ygrid);
    
            Pmat = sparse(Pi, Pj, Pval, Nk,Nk);
        
            % Howard policy iteration
            B = (Idmat-beta*Pmat);
            b = util(gc_val);
            v1p = B\b;
    
            % concavify the resulting function        
            v1 = concavify_func(kgrid,v1p);
        
            v_update = max(abs(v1-v0));
        
            c_update = max(abs(gc_val-gc_val0));
            gc_val0 = gc_val;
        
            v0 = v1;
        
            if ~NoDisp && mod(iter,print_skip) == 0
                disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
            end
        
            if v_update < tolv
                if ~NoDisp
                    disp(['VFI converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
                end
                break;
            end    
        end
        
    elseif Do_pfi == 2 %MPFI

        for iter = 1:maxiter
            
            v = v0;
        
            [gc_val, ~, Pi, Pj, Pval] = solve_and_eval(inv_mutil, beta*v, kgrid, ygrid);
    
            Pmat = sparse(Pi, Pj, Pval, Nk,Nk);
        
            % Modified PFI
            v0p = v0;
            b = util(gc_val);
            bet_P = beta*Pmat;
            for iter_p=1:20
                v1p =  b + bet_P*v0p;
                v0p = v1p;
            end

            % concavify the resulting function        
            v1 = concavify_func(kgrid,v1p);
        
            v_update = max(abs(v1-v0));
        
            c_update = max(abs(gc_val-gc_val0));
            gc_val0 = gc_val;
        
            v0 = v1;
        
            if ~NoDisp && mod(iter,print_skip) == 0
                disp(['Iter. step ', num2str(iter), ': update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
            end
        
            if v_update < tolv
                if ~NoDisp
                    disp(['VFI converged: Step ', num2str(iter), ' w/ update (c) = ', num2str(c_update,5), ' & update (v) = ', num2str(v_update,5)])
                end
                break;
            end    
        
        
        end
    end


    

end


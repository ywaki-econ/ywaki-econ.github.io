clc;

% Model initialization
%----------------------

% Model with grid size = 10000
rm = RamseyModel();
rm.sscalc();
rm.init_grid();

% format shortE
% format compact

% Solve the model using different methods
[v_VFI, gc_VFI, iter_VFI, v_update, c_update] = solve_model(rm,0,0,1e-6,1000,1);
[gc_EGM, polend_EGM, iter_EGM] = solve_model_EGM(rm,c_update,1000,1);
[v_PFI, gc_PFI, iter_PFI] = solve_model(rm,1,1,1e-6,1000,1);
[v_MPFI, gc_MPFI, iter_MPFI] = solve_model(rm,2,1,1e-6,1000,1);

% Obtain the policy functions on the endogneous grid for VFI, PFI, and MPFI
[gc_end_VFI, gk_end_VFI, yend_VFI] = policy_endogenous_grid(rm, v_VFI);
[gc_end_PFI, gk_end_PFI, yend_PFI] = policy_endogenous_grid(rm, v_PFI);
[gc_end_MPFI, gk_end_MPFI, yend_MPFI] = policy_endogenous_grid(rm, v_MPFI);

figure(1)
subplot(3,1,1);plot(rm.kgrid, gc_VFI, 'm-',rm.kgrid, gc_EGM, 'b--', 'LineWidth',2)
title('Consumption policy function (Nk = 10,000)')
legend('VFI', 'EGM')
subplot(3,1,2);plot(rm.kgrid, gc_VFI, 'm-',rm.kgrid, gc_PFI, 'b--','LineWidth',2)
legend('VFI', 'PFI')
subplot(3,1,3);plot(rm.kgrid, gc_VFI, 'm-',rm.kgrid, gc_MPFI, 'b--', 'LineWidth',2)
legend('VFI', 'MPFI')
xlabel('k')
ylabel('c')

disp('Policy function differences on the exogenous grid')
disp(['  max |gc_VFI-gc_EGM|  : ', num2str(max(abs(gc_VFI-gc_EGM)),'%e')])
disp(['  max |gc_PFI-gc_EGM|  : ', num2str(max(abs(gc_PFI-gc_EGM)),'%e')])
disp(['  max |gc_MPFI-gc_EGM| : ', num2str(max(abs(gc_MPFI-gc_EGM)),'%e')])
disp(['  max |gc_VFI-gc_PFI|  : ', num2str(max(abs(gc_VFI-gc_PFI)),'%e')])
disp(['  max |gc_VFI-gc_MPFI|  : ', num2str(max(abs(gc_VFI-gc_MPFI)),'%e')])
disp(['  max |gc_PFI-gc_MPFI|  : ', num2str(max(abs(gc_PFI-gc_MPFI)),'%e')])

% Euler equation error
EEE_VFI = euler_error(rm, gc_end_VFI, yend_VFI, gc_VFI, rm.ygrid-gc_VFI);
EEE_PFI = euler_error(rm, gc_end_PFI, yend_PFI, gc_PFI, rm.ygrid-gc_PFI);
EEE_MPFI = euler_error(rm, gc_end_MPFI, yend_MPFI, gc_MPFI, rm.ygrid-gc_MPFI);
EEE_EGM = euler_error(rm, polend_EGM{"gc_end"}, polend_EGM{"yend"}, gc_EGM, rm.ygrid-gc_EGM);

disp(' ')
disp('Euler equation errors across methods')
disp(['  max |EEE_VFI|  : ', num2str(max(abs(EEE_VFI)),'%e')])
disp(['  max |EEE_EGM|  : ', num2str(max(abs(EEE_EGM)),'%e')])
disp(['  max |EEE_PFI|  : ', num2str(max(abs(EEE_PFI)),'%e')])
disp(['  max |EEE_MPFI|  : ', num2str(max(abs(EEE_MPFI)),'%e')])

% Modification to PFI

maxstep = 3;

gc_modified_mat = zeros(rm.Nk,maxstep);
EEE_modified_mat = zeros(rm.Nk,maxstep);

gc_to_modify = gc_PFI;
for nstep=1:maxstep
    [gc_modified, pol_end_modified] = modify_solution(rm, gc_to_modify, nstep);
    EEE_modified_mat(:,nstep) = euler_error(rm, pol_end_modified{"gc_end"}, pol_end_modified{"yend"}, gc_modified, rm.ygrid-gc_modified);
    gc_modified_mat(:,nstep) = gc_modified;
    disp(['  max |EEE_modified|  : ', num2str(max(abs(EEE_modified_mat(:,nstep))),'%e'), ', Step = ', num2str(nstep)]);
    gc_to_modify = gc_modified;
end

figure(2)
plot(rm.kgrid, abs(EEE_PFI), 'c.', rm.kgrid, abs(EEE_modified_mat(:,1)), 'b.',rm.kgrid, abs(EEE_modified_mat(:,2)), 'm.', rm.kgrid, abs(EEE_modified_mat(:,3)), 'k.')
title('Absolute Euler equation error')
xlabel('k')
legend('PFI', 'PFI + 1-step EGM', 'PFI + 2-step EGM', 'PFI + 3-step EGM','Location','northeast')

n_disp = 10;
figure(3)
plot(rm.kgrid(1:n_disp), gc_PFI(1:n_disp), 'k.', rm.kgrid(1:n_disp), gc_modified_mat(1:n_disp,1), 'b.',...
     rm.kgrid(1:n_disp), gc_modified_mat(1:n_disp,2), 'm.', rm.kgrid(1:n_disp), gc_modified_mat(1:n_disp,3), 'c.', 'MarkerSize',10)
title(['Consumption policy function (Nk = 10,000) at the lowest ', num2str(n_disp), ' grid points'])
legend('PFI', '1-step EGM', '2-step EGM', '3-step EGM', 'Location', 'southeast')

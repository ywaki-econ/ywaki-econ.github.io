
% Huggett model


% parameters
dt = 1; % Set to 0.01 to approximate a continuous-time limit

beta = exp(-0.05*dt);
sigma = 2;


Ne = 2;
evec = [0.2; 0.1]*dt;

if dt < 1/1.2
Tr_e_mat = [1-1.2*dt, 1.2*dt;
            1.2*dt, 1-1.2*dt];
else
Tr_e_mat = [0.8, 0.2;
            0.2, 0.8];
end

[V,D,flag] = eigs(Tr_e_mat',1);
inv_dist_e = V/sum(V);


kmin = -0.15;
kmax = 5; 
Nk = Ngrid;

if LogGrid
    kgrid = kmin+logspace(log10(0.0001),log10(kmax-kmin),Nk)'; % log-spaced grid
else
    kgrid = linspace(kmin, kmax,Nk)';   % equally-spaced grid
end

Dk = kgrid(2:Nk)-kgrid(1:Nk-1);
kind = (1:1:Nk)';


if sigma == 1
    util = @(c) log(c);
    mutil = @(c) c.^(-1);
    inv_mutil = @(mu) mu.^(-1);
else
    util = @(c) real(c.^(1-sigma)/(1-sigma));
    mutil = @(c) real(c.^(-sigma));
    inv_mutil = @(mu) real(mu.^(-1/sigma));
end


maxiter = 1000;
tolv = 1e-6;

v_update = 10;

pol_c = zeros(Nk,Ne);
pol_kp = zeros(Nk,Ne);

Pi_cell = cell(Ne);
Pj_cell = cell(Ne);
Pval_cell = cell(Ne);


RL = 1+0.01*dt;
RH = 1+0.04*dt;
tolA = 1e-5;
tolR = 1e-8;
tolDist = 1e-6;


Nr = 100;

AggAvec = zeros(Nr,1);

cmin = 1e-6;


Idmat = speye(Nk*Ne);



for ir=1:Nr

R = 0.5*(RL+RH);

ProdFunc = @(k,e) R*k+e;

ygrid = zeros(Nk,Ne);
c_guess = zeros(Nk,Ne);

for ie=1:Ne
    ygrid(:,ie) = ProdFunc(kgrid,evec(ie));
    c_guess(:,ie) = ygrid(:,ie)-kgrid;
end

if ir==1
    % initial guess
    v0 = util(c_guess(:))/(1-beta);
    %v0 = util(ygrid(:)-kmin)/(1-beta);
end

v1c = reshape(v0,Nk,Ne);


nnz = zeros(Ne,1);

for iter = 1:maxiter
    
    v = reshape(v0,Nk,Ne);

    nnz0 = 1;
    for ie=1:Ne
        [pol_c(:,ie), pol_kp(:,ie), Pi_cell{ie}, Pj_cell{ie}, Pval_cell{ie}] = solve_and_eval(inv_mutil, beta*v*Tr_e_mat(ie,:)', kgrid, ygrid(:,ie));
        nnz(ie) = length(Pi_cell{ie});
    end

    nnz_all = sum(nnz);

    %% Construction of Ptilde. The following direct method works better for high Ne.
    Ptilde_i = zeros(nnz_all*Ne,1);
    Ptilde_j = zeros(nnz_all*Ne,1);
    Ptilde_val = zeros(nnz_all*Ne,1);

    loc = 0;
    for ie=1:Ne
        nnz_now = nnz(ie);
        for je=1:Ne
            Ptilde_i(loc+1:loc+nnz_now) = Nk*(ie-1)+Pi_cell{ie};
            Ptilde_j(loc+1:loc+nnz_now) = Nk*(je-1)+Pj_cell{ie};
            Ptilde_val(loc+1:loc+nnz_now) = Tr_e_mat(ie,je)*Pval_cell{ie};
            loc = loc + nnz_now;
        end
    end

    Ptildemat = sparse(Ptilde_i(1:loc),Ptilde_j(1:loc),Ptilde_val(1:loc),Ne*Nk, Ne*Nk);


    %% When Ne is low, the following is as good as the above construction.
    % Ptildemat = spalloc(Nk*Ne,Nk*Ne, nnz_all);
    % for ie=1:Ne
    %     Ptildemat(Nk*(ie-1)+1:Nk*ie,:) = kron(Tr_e_mat(ie,:), sparse(Pi_cell{ie} ,Pj_cell{ie}, Pval_cell{ie}, Nk,Nk));
    % end


    % PFI

    if Do_pfi == 1
        
        % Method 1: solve the matrix equation exactly

        v1p = (Idmat-beta*Ptildemat)\util(pol_c(:));
        % concavify the resulting function
        v1p = reshape(v1p,Nk,Ne);
    
        if Use_mex == 1
            for ie=1:Ne
            v1c(:,ie) = concavify_mex(kgrid, v1p(:,ie));
            end
        else
            for ie=1:Ne
            v1c(:,ie) = concavify(kgrid, v1p(:,ie));
            end
        end            

        v1 = v1c(:);
        v_update = max(abs(v1-v0));
        v0 = v1;

    elseif Do_pfi == 2
        % Method 2: iterate for a finite number of times
        v0p = v0;
        uvec = util(pol_c(:));
        bet_P = beta*Ptildemat;
        for iter_p=1:20
            v1p =  uvec + bet_P*v0p;
            v0p = v1p;
        end

        % concavify the resulting function
        v1p = reshape(v1p,Nk,Ne);
    
        if Use_mex == 1
            for ie=1:Ne
            v1c(:,ie) = concavify_mex(kgrid, v1p(:,ie));
            end
        else
            for ie=1:Ne
            v1c(:,ie) = concavify(kgrid, v1p(:,ie));
            end
        end         
        v1 = v1c(:);
        v_update = max(abs(v1-v0));
        v0 = v1;
    
    else 

        v0 = util(pol_c(:)) + beta*Ptildemat*v0;

    end


    if v_update < tolv
        break;
    end


end

if ~NoDisp
    disp(['Iteration step = ', num2str(iter), ', updating distance = ', num2str(v_update,10)])
end




% % invariant distribution

% Method 1: compute an eigenvector associated with the largest eigenvalue

% [V,D,flag] = eigs(Ptildemat',1);
% inv_dist = V/sum(V);

% Method 2: Iterate for a fixed, finite number of times
% if ir ==1
%    inv_dist = ones(Nk*Ne,1)/(Nk*Ne);
% end
% 
% for iter_p = 1:100
%     inv_dist1 = Ptildemat'*inv_dist;
%     inv_dist = inv_dist1;
% end
 
% Method 3:  Moll's "dirty trick" [taken from his huggett_equilibrium_iterate.m]

AT = Ptildemat'-speye(Nk*Ne);
b = zeros(Ne*Nk,1);

i_fix = 1;
b(i_fix)=.1;
row = [zeros(1,i_fix-1),1,zeros(1,Ne*Nk-i_fix)];
AT(i_fix,:) = row;

inv_dist = AT\b;
inv_dist = inv_dist./sum(inv_dist);

% Aggregate savings
AggA = inv_dist'*repmat(kgrid,Ne,1);


% Bisection method update
if (RH-RL)<tolR | abs(AggA)<tolA
    break    
elseif AggA>tolA
    RH = R; 
elseif AggA<-tolA
    RL = R;
end

AggAvec(ir) = AggA;


end


if ~NoDisp
    disp(['Iteration step = ', num2str(iter), ', updating distance = ', num2str(v_update,10)])
    disp(['Aggregate savings = ', num2str(AggA)])
end


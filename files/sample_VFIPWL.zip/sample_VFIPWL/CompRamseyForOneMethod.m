
% This program solves the deterministic Ramsey model for a particular soluton method. 
% Change Do_pfi parameter to change the solution method.

close all

% Misc. parameters
NoDisp = 1; % Set to 1 to display nothing, and 0 to display figures etc. 
Do_pfi = 0; % Set to 1 for PFI, 2 for MPFI (J=20), and 0 for VFI
LogGrid = 0; % Set to 1 for log-spaced grid, and 0 for equally-spaced grid
Use_mex = 1; % Set to 1 to use a mex function for concavification, and 0 otherwise. Not used for VFI.

Ngrid = 10000;  % grid size 

TotalIter = 1; % Repeat the computation for TotalIter times and compute the average time.
                 % Setting TotalIter = 1 makes the average time a little bit
                 % higher than in Tables 1 and 2. For comparable results,
                 % set it to e.g. 100 or 1000. 


% Solve the model

if Do_pfi == 0
    disp('Solution method: VFI')
elseif Do_pfi == 1
    disp('Solution method: PFI')
elseif Do_pfi == 2
    disp('Solution method: MPFI')
end

if LogGrid
    disp('Log-grid')
else
    disp('Equally-spaced grid')
end

if Use_mex
    disp('Mex functions are used')
else
    disp('No Mex functions are used')
end

disp(['Grid size = ', num2str(Ngrid)])


% Solve the model
tic;

for ll=1:TotalIter
    Ramsey;
end

Time = toc;

disp(['Iteration step = ', num2str(iter), ', updating distance = ', num2str(v_update,10)])

disp(['Ave. comp. time = ', num2str(Time/TotalIter), ' sec. (ave. of ', num2str(TotalIter), ' repetition)'])

% Euler equation error

[gc, gk, yend] = solve_only(inv_mutil, beta*v0, kgrid, ygrid(end));

EEerror = inv_mutil( beta*mutil( interp1(yend, gc, ProdFunc(gk_val) ) ).*MProdFunc(gk_val) )./gc_val-1;
disp('Euler equation error')
disp(max(abs(EEerror)))

% Plotting
figure(1);
subplot(3,1,1);plot(kgrid, gc_val,'r-');xlabel('current k');ylabel('c');
title('Policy functions (as functions of current k)')
subplot(3,1,2);plot(kgrid, gk_val, 'r-', kgrid, kgrid, 'k--');xlabel('current k');ylabel('next period k');legend('policy','45 deg. line')
subplot(3,1,3);plot(kgrid, gk_val-kgrid, 'r-');yline(0, 'k--');xlabel('current k');ylabel('\Delta k');

figure(2);
spy(Pmat)
title('Sparsity pattern of the transition matrix, P')

figure(3);
subplot(2,1,1);plot(yend, gc,'r-');xline(yend(end-1), 'b--');xlabel('cash-on-hand');ylabel('c');legend('g_c(y)', 'y^{end}_{2I_k-1}', 'Location','northwest')
axis([0, 2.6, 0, 0.8])
title('Policy functions (as functions of current cash-on-hand)')
subplot(2,1,2);plot(yend, gk, 'r-');xline(yend(end-1), 'b--');xlabel('cash-on-hand');ylabel('next period k');legend('g_k(y)', 'y^{end}_{2I_k-1}', 'Location','northwest')
axis([0, 2.6, 0, 2.2])


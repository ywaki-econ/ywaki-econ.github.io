% This program solves the Huggett model for a particular soluton method. 
% Change Do_pfi parameter to change the solution method.

close all;

% Misc. parameters
NoDisp = 1; % Set to 1 to display nothing, and 0 to display figures etc. 
Do_pfi = 1; % Set to 1 for PFI, 2 for MPFI (J=20), and 0 for VFI 
LogGrid = 0; % Set to 1 for log-spaced grid, and 0 for equally-spaced grid
Use_mex = 1; % Set to 1 to use a mex function for concavification, and 0 otherwise. Not used for VFI.

Ngrid = 1000;  % grid size 

TotalIter = 1; % Repeat the computation for TotalIter times and compute the average time.
                 % Setting TotalIter = 1 makes the average time a little bit
                 % higher than in Tables 1 and 2. For comparable results,
                 % set it to e.g. 100 or 1000. 


% Solve the model

if Do_pfi == 0
    disp('Solution method: VFI')
elseif Do_pfi == 1
    disp('Solution method: PFI')
elseif Do_pfi == 2
    disp('Solution method: MPFI')
end

if LogGrid
    disp('Log-grid')
else
    disp('Equally-spaced grid')
end

if Use_mex
    disp('Mex functions are used')
else
    disp('No Mex functions are used')
end

disp(['Grid size = ', num2str(Ngrid)])



% Solve the model
tic;

for ll=1:TotalIter
    HuggettGE;
end

Time = toc;

disp(['Ave. comp. time = ', num2str(Time/TotalIter), ' sec. (ave. of ', num2str(TotalIter), ' repetition)'])


disp(['Iteration step = ', num2str(iter), ', updating distance = ', num2str(v_update,10)])
disp(['Outer loop steps = ', num2str(ir)])
disp(['Aggregate savings = ', num2str(AggA)])

kdisp_l = 0.6;
kdisp_h = kmin-0.03;


figure(1);
plot(kgrid, (pol_kp(:,1)-kgrid)/dt, 'r-',kgrid, (pol_kp(:,2)-kgrid)/dt, 'b-', 'LineWidth',2);ylabel("\Delta a/\Delta t")
title('Policy functions')
xlim([kdisp_h kdisp_l])
ylim([-0.1, 0.08])
xline(kmin)
yline(0)
legend('z high','z low')


figure(2);
plot(kgrid, inv_dist(1:Nk)/(max(Dk)), 'r-', kgrid, inv_dist(Nk+1:2*Nk)/(max(Dk)), 'b-', 'LineWidth',2)
ylabel("Conditional density")
xlim([kdisp_h kdisp_l])
ylim([0 3])
xline(kmin)
legend('g(a,z high)','g(a,z low)')

figure(3);
plot(kgrid, cumsum(inv_dist(1:Nk)/inv_dist_e(1)), 'r-', kgrid, cumsum(inv_dist(Nk+1:2*Nk)/inv_dist_e(2)), 'b-', 'LineWidth',2)
ylabel("Conditional cumulative distribution")
xlim([kdisp_h kdisp_l])
ylim([0 1])
xline(kmin)
legend('G(a|z high)','G(a|z low)')


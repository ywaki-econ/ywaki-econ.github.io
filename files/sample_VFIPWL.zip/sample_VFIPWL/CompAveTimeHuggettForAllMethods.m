clear;
clc; 

% This program computes the average time for Huggett model using PFI and
% MPFI

% Common misc. parameters
NoDisp = 1;
LogGrid = 0; % Set to 1 for log-spaced grid, and 0 for equally-spaced grid
Use_mex = 1; % Set to 1 to use a mex function for concavification, and 0 otherwise

TotalIter = 1000;


for Do_pfi = 1:2

    for i=1:2

    Ngrid = 10*10^i;

    tic
    for m=1:TotalIter
        HuggettGE;
    end

    TotalTime =toc;

    if Do_pfi == 1
        disp(['PFI results, Nk = ', num2str(Ngrid)])
    else
        disp(['MPFI results, Nk = ', num2str(Ngrid)])
    end        
    AveTime = TotalTime/TotalIter;
    disp(['   Average time = ', num2str(AveTime),  ' , Outer loop steps = ', num2str(ir)])

    end
end


clear;
clc; 

% This program produces numbers reported in Table 1, 2, and 3 for the
% discrete-time model.


% Common misc. parameters
NoDisp = 1;
LogGrid = 0; % Set to 1 for log-spaced grid, and 0 for equally-spaced grid
Use_mex = 1; % Set to 1 to use a mex function for concavification, and 0 otherwise

TotalIter = 1000;


disp(['For each solution method, solve the model ', num2str(TotalIter), ' times and compute the average time taken...'])

for Do_pfi = 0:2    % Do_pfi = 1 for PFI, 2 for MPFI (J=20), and 0 for VFI

for i=1:2

    Ngrid = 100*10^i;

    tic
    for m=1:TotalIter
        Ramsey;
    end
    
    TotalTime =toc;
    
    if Do_pfi == 0
        disp(['VFI results, Nk = ', num2str(Ngrid)])
    elseif Do_pfi == 1
        disp(['PFI results, Nk = ', num2str(Ngrid)])
    else
        disp(['MPFI results, Nk = ', num2str(Ngrid)])
    end        
    AveTime = TotalTime/TotalIter;
    AveTimeperIter = AveTime/iter;
    iter;
    disp(['   Iteration steps = ', num2str(iter), ' , Average time = ', num2str(AveTime),  ' , Average time per step = ', num2str(AveTimeperIter)])

end

end


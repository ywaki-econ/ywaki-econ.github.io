# Description

This folder contains a set of sample code for Waki (2025). "Fitted Value Iteration with Piecewise Linear Interpolation for Efficient Solution of Income Fluctuation Problems and Equilibrium Computation in Heterogeneous-Agent Models."

# Files in the folder

## Ramsey model
* CompRamseyForOneMethod.m : Set misc. parameters, call Ramsey.m to solve the model using a user-specified method (VFI, PFI, or MPFI), and plot the results. 
* CompAveTimeRamseyForAllMethods.m : Calculate the average computational time for all methods (VFI, PFI, and MPFI) for two grid sizes (I_k = 1,000 and 10,000).
* Ramsey.m : Called from the above two programs. Model parameters are set in this program, and numerically solve DP of the planning problem.

## Huggett model
* CompHuggettForOneMethod.m : Set misc. parameters, call HuggettGE.m to solve the model using a user-specified method (VFI, PFI, or MPFI), and plot the results. 
* CompAveTimeHuggettForAllMethods.m : Calculate the average computational time for all methods (VFI, PFI, and MPFI) for two grid sizes (I_k = 1,000 and 10,000).
* HuggettGE.m : Called from the above two programs. Model parameters are set in this program, and numerically solve for a stationary equilibrium. 

## Method [Used for the Ramsey and the Huggett models]
* solve_and_eval.m : Implement the algorithm 1 in the paper to evaluate the analytical policy function on an EXOGENOUS cash-on-hand grid. Called from Ramsey.m.
* solve_only.m : Implement the algorithm 1 in the paper to obtain the analytical policy function on an ENDOGENOUS cash-on-hand grid. Called from CompRamseyForOneMethod.m.
* find_subinterval.m : A subroutine that takes two increasing grids, xq and x, and for each element of xq[i], find j such that x[j] <= xq[i] <= x[j+1] and non-negative weights, w_l[i] and w_h[i], such that  xq[i] = w_l[i]x[j] + w_h[i]x[j+1]. Called from solve_only.m and solve_and_eval.m.
* concavify.m : Concavify the value function obtained by PFI


# Mexifying the m-function
I have experimented which part of the code should be mexfied, and found that it is most effective to mexify the concavification step in PFI and MPFI. 

The concavification step is implemented by an m function, concavify.m. To generate a mex function from concavify.m, open this folder in Matlab and execute the following command in the Command Window:

    codegen concavify

To use the generated mex function, set Use_mex = 1 in  CompRamseyForOneMethod.m and CompAveTimeRamseyForAllMethods.m. If the mex function cannot be generated, set Use_mex = 0 and the programs use the m function instead. 

Note that this option matters only for PFI and MPFI, and it does not make a difference for VFI. 

# Euler equation error
This paper focuses on the computational time and does not discuss the Euler equation error. It is computed in CompRamseyForOneMethod.m. If you want to reduce the error, try one of the following or both:
1. Set LogGrid = 1 in CompRamseyForOneMethod.m. This option uses a log-spaced grid instead of an equally-spaced grid.
2. Increase kmin in Ramsey.m. The default value is kmin = 0.001*kss, i.e., 0.1% of the steady-state value, which is too low.  

# Continuous-time limit of the Huggett Model
For the Huggett model, there is a parameter dt that can be set in HuggettGE.m. It represents the length of a time interval, and the default value is 1 (discrete-time). By lowering this value, one can appoximate its continuous-time limit. In particular, when dt is set to 0.01, the conditional densities for asset becomes (visually) indistinguishable to the output of Ben Moll's code. 

Note that the value of dt cannot be made lower. 


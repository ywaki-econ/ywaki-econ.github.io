function [loc, w_l, w_h] = find_subinterval(xq,x)

%#codegen
arguments
    xq (:,:) double
    x (:,:) double
end 


% For
%  xq : Nxq*1 matrix
%  x : Nx*1 matrix
% the function finds loc and weights so that for each i
%  x[loc] <= xq[i] < x[loc+1]
%  xq[i] = w_l[i]*x[loc] +w_h[i]*x[loc+1]
%  w_l[i]+w_h[i] = 1
%
% Requirements: 
%   1. For each m, xq(:,m) and x(:,m) are in an ascending order.
%   2. For each (i,m), x(1,m) <= xq(i,m) < x(end,m).

Nxq = length(xq);
Nx = length(x);

loc = zeros(Nxq, 1);
w_l = zeros(Nxq, 1);
w_h = zeros(Nxq, 1);

xloc_now = 1;
for iq = 1:Nxq
    xq_now = xq(iq,1);
    for xloc = xloc_now:(Nx-1)
        if x(xloc+1,1) > xq_now
            loc(iq, 1) = xloc;
            w = (x(xloc+1,1)-xq_now)./(x(xloc+1,1)-x(xloc,1));
            w_l(iq,1) = w;
            w_h(iq,1) = 1-w;
            xloc_now = xloc;
            break;
        end
    end
end

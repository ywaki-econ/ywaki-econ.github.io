function [gc_val, gk_val, Pi, Pj, Pval] = solve_and_eval(inv_mutil, betav, kgrid, ygrid)


% inv_mutil: a function handle that computes the inverse of marginal utility
% betav: beta*v, where v is a vector of value function evaluated on kgrid
% kgrid: a vector of grid points for savings
% ymax: the maximal cash-on-hands possible

Nk = length(kgrid);

betaDv = diff(betav)./diff(kgrid);
lambda = betaDv;

cstar = inv_mutil(lambda);

ymax = ygrid(end);

yL = kgrid(1);
yH = max([cstar(end)+kgrid(Nk), ymax])+0.1*abs(ymax);

cend = yH-kgrid(end);

% Endogenous grid
yend = zeros(2*Nk,1);

yend(1) = yL;
yend(2*Nk) = yH;


for ik=1:Nk-1
    yend(2*ik) = cstar(ik)+kgrid(ik);
    yend(2*ik+1) = cstar(ik)+kgrid(ik+1);
end

Ny = length(ygrid);
Nyend = length(yend);

yqind = (1:1:Ny)';
yind = (1:1:Nyend)';

gc_val = zeros(Ny,1);
gk_val = zeros(Ny,1);

[loc, w_l, w_h] = find_subinterval(ygrid,yend);


% I intervals

isI = mod(loc,2)==0;

iloc_I = yqind(isI);
jloc_I = yind(loc(isI));

jk_I = (jloc_I)/2;
jk_Iplus1 = jk_I+1;

gc_val(iloc_I) = cstar(jk_I);
kp = w_l(iloc_I).*kgrid(jk_I)+w_h(iloc_I).*kgrid(jk_Iplus1);
gk_val(iloc_I) = kp;
wk_I = (kgrid(jk_Iplus1)-kp)./(kgrid(jk_Iplus1)-kgrid(jk_I));

% J intervals
isJ = ~isI;
iloc_J = yqind(isJ);
jloc_J = yind(loc(isJ));

jk_J = (jloc_J+1)/2;

jk_Jis1 = (jk_J==1);
jk_JisEnd = (jk_J==Nk);
jk_JisInt = (jk_J>1)&(jk_J<Nk);


gc_val(iloc_J(jk_Jis1)) = w_h(iloc_J(jk_Jis1)).*cstar(jk_J(jk_Jis1));
gc_val(iloc_J(jk_JisInt)) = w_l(iloc_J(jk_JisInt)).*cstar(jk_J(jk_JisInt)-1)+w_h(iloc_J(jk_JisInt)).*cstar(jk_J(jk_JisInt));
gc_val(iloc_J(jk_JisEnd)) = w_l(iloc_J(jk_JisEnd)).*cstar(jk_J(jk_JisEnd)-1)+w_h(iloc_J(jk_JisEnd)).*cend;

gk_val(iloc_J) = kgrid(jk_J);
wk_J = ones(length(iloc_J),1);
ik_J = (jloc_J+1)/2;

% Collect non-zero elements of P
Pi = [iloc_I; iloc_I; iloc_J];
Pj = [jk_I; jk_Iplus1; ik_J];
Pval = [wk_I; 1-wk_I; wk_J];


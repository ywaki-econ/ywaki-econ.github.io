

% Ramsey model

% Misc. parameters [They are set in CompAveTimeRamseyForAllMethods.m and CompRamseyForOneMethod.m]

% NoDisp = 0; % Set to 1 to display nothing, and 0 to display figures etc. 
% Do_pfi = 1; % Set to 1 for PFI, 2 for MPFI (J=20), and 0 for VFI
% LogGrid = 0; % Set to 1 for log-spaced grid, and 0 for equally-spaced grid
% Use_mex = 0; % Set to 1 to use a mex function for concavification, and 0 otherwise
% Ngrid = 10000;  % grid size 

% Model parameters
beta = 1/(1+0.05);
alpha = 0.3;
delta = 0.05;
A = (1/beta-1+delta)/alpha;
sigma = 2;

ProdFunc = @(k) A*k.^alpha+(1-delta)*k;
MProdFunc = @(k) alpha*A*k.^(alpha-1)+(1-delta);

kss = ((1/beta - 1+delta)/(alpha*A))^(1/(alpha-1));
yss = ProdFunc(1);

kmin = 0.001*kss;
kmax = 2*kss;
Nk = Ngrid;

if LogGrid
    kgrid = logspace(log10(kmin),log10(kmax),Nk)'; % log-spaced grid
else
    kgrid = linspace(kmin, kmax,Nk)';   % equally-spaced grid
end

Dk = diff(kgrid);
kind = (1:1:Nk)';

ygrid = ProdFunc(kgrid);

if sigma == 1
    util = @(c) log(c);
    mutil = @(c) c.^(-1);
    inv_mutil = @(mu) mu.^(-1);
else
    util = @(c) real(c.^(1-sigma)/(1-sigma));
    mutil = @(c) real(c.^(-sigma));
    inv_mutil = @(mu) real(mu.^(-1/sigma));
end

% initial guess
v0 = util(ProdFunc(kgrid)-kgrid)/(1-beta);

maxiter = 1000;
tolv = 1e-6;

v_update = 10;

ind_interval = zeros(Nk,1);

cmin = 1e-6;
yL = kgrid(1)+cmin;

Idmat = speye(Nk);

for iter = 1:maxiter
    
    v = v0;

    [gc_val, gk_val, Pi, Pj, Pval] = solve_and_eval(inv_mutil, beta*v, kgrid, ygrid);
    Pmat = sparse(Pi, Pj, Pval, Nk,Nk);

    if Do_pfi == 1
        % Howard policy iteration
        B = (Idmat-beta*Pmat);
        b = util(gc_val);
        v1p = B\b;

        % concavify the resulting function        
        if Use_mex == 1
            v1 = concavify_mex(kgrid,v1p);
        else
            v1 = concavify(kgrid,v1p);
        end            
    elseif Do_pfi == 2
        % Modified PFI
        v0p = v0;
        b = util(gc_val);
        bet_P = beta*Pmat;
        for iter_p=1:20
            v1p =  b + bet_P*v0p;
            v0p = v1p;
        end
        % concavify the resulting function        
        if Use_mex == 1
            v1 = concavify_mex(kgrid,v1p);
        else
            v1 = concavify(kgrid,v1p);
        end            
    else
        v1 = util(gc_val)+beta*Pmat*v;
    end

    v_update = max(abs(v1-v0));

    v0 = v1;

%    disp(['Iteration step = ', num2str(iter), ', updating distance = ', num2str(v_update,10)])
    if v_update < tolv
        break;
    end



end


if ~NoDisp
disp(['Iteration step = ', num2str(iter), ', updating distance = ', num2str(v_update,10)])
end


